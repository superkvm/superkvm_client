# res/qss

本目录用于存放每个 UI 组件独立的 css 样式文件。

- 每个 UI 组件应有独立的 .css 文件，命名建议与类名或功能相关。
- 样式文件可参考 playerdemo 项目中的 qss 文件，也可直接复用。
- 在各自 UI 构造函数中通过 //setStyleSheet(getQssString("qss文件路径")) 加载。
- getQssString 是一个独立的工具函数，不依赖 GlobalHelper。 